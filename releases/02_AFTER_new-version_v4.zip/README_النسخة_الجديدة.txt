🚀 النسخة الجديدة (بعد كل التحديثات)
=====================================
5 مراحل تطوير كاملة، بدون حذف أي ميزة قائمة.

الملفات الجديدة:
 • botlog.py  — سجلات مركزية + درع أعطال + تنبيه الأدمن
 • bot11.py   — /cancel العام + معالج الدفع الموحّد + تنقّل موحّد
 • bot12.py   — بطاقة العضوية + الشارات + المتصدرون + تأكيد الشراء + تنبيه المخزون
 • bot13.py   — مركز قيادة الأدمن (/dash + بحث + تدقيق + إذاعة + CSV)
 • PROJECT_MAP.md / README.md / .env.example
 • tests/     — 46 اختباراً آلياً (run_all.py)

طريقة التشغيل:
 1) pip install -r requirements.txt
 2) انسخ .env.example إلى .env واملأ API_TOKEN و DATABASE_URL
 3) python bot.py

التفاصيل الكاملة في README.md و PROJECT_MAP.md
